from django.urls import path
from thecurator.views import *

urlpatterns = [
    path("", inicio, name= "Inicio"),
    path("catalogo/", catalogo, name= "Catálogo"),
    path("preventa/", preventa, name= "Preventa"),
    path("sucursales/", sucursales, name= "Sucursales"),
    path("catalogoFormulario/", catalogoFormulario, name= "FormularioCatalogo"),
    path("preventaFormulario/", preventaformulario, name= "FormularioPreventa"),
    path("sucursalesFormulario/", sucursalesformulario, name= "FormularioSucursales"),
    path("busquedaSucursales/", busquedaSucursales, name="BuscarSucursal"),
    path("resultados/", resultados, name="ResultadosSucursal"),
]