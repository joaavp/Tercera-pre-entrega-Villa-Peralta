from django.db import models

# Create your models here.

class Catalogo(models.Model):
    disco = models.CharField(max_length=50)
    artista = models.CharField(max_length=50)

class Preventa(models.Model):
    discopre = models.CharField(max_length=50)
    artistapre = models.CharField(max_length=50)

class Sucursales(models.Model):
    direccion = models.CharField(max_length=50)
    localidad = models.CharField(max_length=30)
    telefono = models.IntegerField()

