from django.shortcuts import render
from django.http import HttpResponse
from thecurator.models import Catalogo, Preventa, Sucursales

# Create your views here.

def inicio(request):

    return render(request, "thecurator/inicio.html")

def catalogo(request):
    
    return render(request, "thecurator/catalogo.html")

def preventa(request):

    return render(request, "thecurator/preventa.html")

def sucursales(request):

    return render(request, "thecurator/sucursales.html")

def catalogoFormulario(request):

    if request.method == "POST":

        disco = Catalogo(disco=request.POST["disco"], artista=request.POST["artista"])

        disco.save()

        return render(request, "thecurator/inicio.html")

    return render(request, "thecurator/catalogo.html")

def preventaformulario(request):

    if request.method == "POST":

        discopre = Preventa(discopre=request.POST["disco"], artistapre = request.POST["artista"])

        discopre.save()

        return render(request, "thecurator/inicio.html")   

    return render(request, "thecurator/preventa.html")

def sucursalesformulario(request):

    if request.method == "POST":

        sucursal = Sucursales(direccion=request.POST["direccion"], localidad=request.POST["localidad"], telefono=request.POST["telefono"])

        sucursal.save()

        return render(request, "thecurator/inicio.html")

    return render(request, "thecurator/sucursales.html")


def busquedaSucursales(request):

    return render(request, "thecurator/sucursales.html")

def resultados(request):

    if request.GET["localidad"]:

        localidad=request.GET["localidad"]
        sucursales=Sucursales.objects.filter(localidad__icontains=localidad)

        return render(request, "thecurator/sucursales.html", {"sucursales":sucursales, "localidad":localidad})

    else:

        respuesta = "No se encontraron resultados."


    return HttpResponse(respuesta)
