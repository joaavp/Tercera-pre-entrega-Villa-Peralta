from django.contrib import admin
from thecurator.models import *
# Register your models here.

admin.site.register(Catalogo)
admin.site.register(Preventa)
admin.site.register(Sucursales)